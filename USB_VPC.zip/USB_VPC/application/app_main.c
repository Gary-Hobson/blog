// #include "application.h"

// void SystemClock_Config(void);
// void MX_GPIO_Init(void);
// void MX_USART1_UART_Init(void);

// __weak void Hardware_Init(void)
// {
//     HAL_Init();
//     SystemClock_Config();
//     MX_GPIO_Init();
// }

// int main(void)
// {
//     Hardware_Init();
//     setup();

//     while (1)
//     {
//         loop();
//     }
    
// }
